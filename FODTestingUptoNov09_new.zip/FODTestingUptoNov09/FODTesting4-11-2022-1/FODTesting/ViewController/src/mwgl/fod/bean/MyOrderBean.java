package mwgl.fod.bean;

import javax.faces.event.ActionEvent;

import oracle.adf.model.BindingContext;

import oracle.binding.OperationBinding;

public class MyOrderBean {
    public MyOrderBean() {
    }

    public void invokeCanelAction(ActionEvent actionEvent) {
        OperationBinding ob = BindingContext.getCurrent().getCurrentBindingsEntry().getOperationBinding("cancelOrder");
        ob.execute();
    }
}
